output "alb_dns_name" {
  description = "Public DNS name of the Application Load Balancer"
  value       = aws_lb.alb.dns_name
}

output "alb_url" {
  description = "Convenience HTTP URL for the ALB"
  value       = "http://${aws_lb.alb.dns_name}"
}
